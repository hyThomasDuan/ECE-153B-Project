#include "SPI.h"
#include "SysTimer.h"
#include "accelerometer.h"

void accWrite(uint8_t addr, uint8_t val){
	//TODO
}

uint8_t accRead(uint8_t addr){
	//TODO
}

void initAcc(void){
	//TODO
}

void readValues(double* x, double* y, double* z){
	//TODO
}
