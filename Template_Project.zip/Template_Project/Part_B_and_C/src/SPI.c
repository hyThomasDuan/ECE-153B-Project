#include "SPI.h"
#include "SysTimer.h"

void SPI1_GPIO_Init(void) {
	//TODO
}


void SPI1_Init(void){
	//TODO 
}

uint16_t SPI_Transfer_Data(uint16_t write_data){
	//TODO
}
