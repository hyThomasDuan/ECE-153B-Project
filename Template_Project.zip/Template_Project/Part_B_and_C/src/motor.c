/*
 * ECE 153B
 *
 * Name(s):
 * Section:
 * Project
 */

#include "stm32l476xx.h"
#include "motor.h"

static const uint32_t MASK = 0;//TODO
static const uint32_t HalfStep[8] = {0,0,0,0,0,0,0,0};//TODO

static volatile int8_t dire = 0;
static volatile uint8_t step = 0;

void Motor_Init(void) {	
	//TODO
}

void rotate(void) {
	//TODO
}

void setDire(int8_t direction) {
	//TODO
}
	


