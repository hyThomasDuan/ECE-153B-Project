/*
 * ECE 153B
 *
 * Name(s):
 * Section:
 * Project
 */

#include "LED.h"

void LED_Init(void){
	//TODO
}

void LED_On(void){
	//TODO
}

void LED_Off(void){
	//TODO
}

void LED_Toggle(void){
	//TODO
}
